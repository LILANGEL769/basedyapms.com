<script>
	import '$lib/styles/global.css';
</script>

<slot />
