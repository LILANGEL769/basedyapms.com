<div class="flex w-full mt-5 lg:mr-10 flex-wrap gap-y-4 justify-center md:justify-start gap-x-4 overflow-y-auto" >
    <slot/>
</div>
