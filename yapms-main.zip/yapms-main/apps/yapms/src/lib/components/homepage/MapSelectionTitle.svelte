<script lang="ts">
    export let title: string
</script>

<div class="text-2xl text-center md:text-left text-bold pr-5 mt-4">
    {title}
</div>
