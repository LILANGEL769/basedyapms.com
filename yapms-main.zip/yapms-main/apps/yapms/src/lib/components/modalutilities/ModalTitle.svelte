<script lang="ts">
  export let title: string;
</script>

<h3 class="text-2xl pb-3">
  {title}
</h3>