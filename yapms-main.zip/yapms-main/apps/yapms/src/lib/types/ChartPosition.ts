type ChartPosition = 'bottom' | 'left';

export default ChartPosition;
