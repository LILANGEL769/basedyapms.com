export type Mode = 'fill' | 'edit' | 'disable' | 'lock';
