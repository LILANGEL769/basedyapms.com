type HomeLinkData = {
	label: string;
	modal: boolean;
	route: string;
};

export default HomeLinkData;
