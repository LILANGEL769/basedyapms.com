export type ChartType = 'battle' | 'pie';
