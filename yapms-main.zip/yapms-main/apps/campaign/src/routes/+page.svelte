<h1>YAP Campaign</h1>
<p>This is a placeholder for the YAP Campaign project.</p>
<p>
	Inspired by:
	<a href="https://newcampaigntrail.github.io/www.americanhistoryusa.com/campaign-trail/index.html"
		>newcampaigntrail</a
	>
	&
	<a href="https://www.americanhistoryusa.com/campaign-trail/">campaigntrail</a>
</p>
