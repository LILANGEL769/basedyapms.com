module.exports = {
	root: true,
	extends: ['yapms'],
	parserOptions: {
		project: './tsconfig.json',
		tsconfigRootDir: __dirname
	}
};
