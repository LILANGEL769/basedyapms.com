<h1>YAP Compass</h1>
<p>This is a placeholder for the YAP Compass project.</p>
<p>
	Inspired by:
	<a href="https://www.politicalcompass.org/test"> The Political Compass </a>
	&
	<a href="https://sapplyvalues.github.io/"> Sapply Values </a>
	&
	<a href="https://8values.github.io/"> 8 Values </a>
</p>
